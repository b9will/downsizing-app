import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'motion/react'
import { X, Zap, ImagePlus, Check } from 'lucide-react'
import { Segmented, Sheet, TagChips, Toast } from '../components/ui'
import { ai } from '../lib/ai'
import { snapshot, useCamera } from '../lib/camera'
import { fileToDataUrl, useStore } from '../lib/hooks'
import { itemCatalog } from '../lib/itemCatalog'
import { identifyItems } from '../lib/scan'
import { now, store, uid } from '../lib/store'
import { type SizeClass, type Tag } from '../lib/types'

type Match = Awaited<ReturnType<typeof identifyItems>>[number]
type Draft = { photo: string; name: string; size: SizeClass; tag: Tag | null; recipient: string }

const SIZE_OPTS: Array<[SizeClass, string]> = [['small', 'Small'], ['medium', 'Medium'], ['large', 'Large'], ['oversize', 'Huge']]

export default function Scan() {
  const { roomId = '' } = useParams()
  const nav = useNavigate()
  const job = useStore(() => store.getJob())
  const room = useStore(() => (job ? store.listRooms(job.id).find((r) => r.id === roomId) : undefined))
  const count = useStore(() => (job && room ? store.listItems(job.id, room.id).length : 0))

  const [draft, setDraft] = useState<Draft | null>(null)
  const { video, state } = useCamera(!draft)
  const [live, setLive] = useState<Match[]>([])
  const [flash, setFlash] = useState(false)
  const [saved, setSaved] = useState<{ id: string; name: string } | null>(null)
  const [modelReady, setModelReady] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  // Live detection loop on the stream.
  useEffect(() => {
    if (state !== 'live' || draft) return
    const v = video.current
    if (!v) return
    let on = true
    let t: ReturnType<typeof setTimeout>
    const tick = async () => {
      try {
        const found = await identifyItems(v)
        if (!on) return
        setModelReady(true)
        setLive(found)
      } catch { if (on) setLive([]) }
      if (on) t = setTimeout(tick, 300)
    }
    void tick()
    return () => { on = false; clearTimeout(t) }
  }, [state, draft, video])

  useEffect(() => {
    if (!saved) return
    const t = setTimeout(() => setSaved(null), 3500)
    return () => clearTimeout(t)
  }, [saved])

  if (!job || !room) return null

  const startDraft = (photo: string, m?: Match) => {
    const name = m?.name ?? ''
    const size = m?.size ?? itemCatalog.find((i) => i.name === name)?.size ?? ai.suggestTag(name)?.size ?? 'medium'
    const s = ai.suggestTag(name)
    setDraft({ photo, name, size, tag: s && s.tag !== 'undecided' ? s.tag : null, recipient: '' })
  }

  const shutter = (m?: Match) => {
    const v = video.current
    if (!v) return
    const photo = snapshot(v)
    if (!photo) return
    setFlash(true); setTimeout(() => setFlash(false), 120)
    if (navigator.vibrate) navigator.vibrate(10)
    // Pick the centred detection if the user tapped the shutter rather than a box.
    const pick = m ?? live.find((x) => x.centered) ?? live[0]
    startDraft(photo, pick)
  }

  const fromFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; e.target.value = ''
    if (!f) return
    const photo = await fileToDataUrl(f, 1024, 0.72)
    let m: Match | undefined
    try { const found = await identifyItems(photo); m = found.find((x) => x.centered) ?? found[0] } catch { /* no detection */ }
    startDraft(photo, m)
  }

  const save = () => {
    if (!draft || !draft.name.trim() || !draft.tag) return
    const id = uid()
    store.saveItem({
      id, jobId: job.id, roomId: room.id, name: draft.name.trim(), size: draft.size, tag: draft.tag, photo: draft.photo,
      familyRecipient: draft.tag === 'family' ? draft.recipient.trim() || undefined : undefined,
      createdAt: now(), updatedAt: now(),
    })
    if (navigator.vibrate) navigator.vibrate([10, 30, 10])
    setSaved({ id, name: draft.name.trim() })
    setDraft(null)
  }

  const hint = state === 'denied' ? 'Camera is off. Allow it in Settings, or add a photo.'
    : state === 'unsupported' ? 'Live camera needs a secure connection. Add a photo instead.'
    : state !== 'live' ? 'Opening camera…'
    : !modelReady ? 'Warming up…'
    : live.length ? 'Tap an item, or press the button' : 'Point at an item'

  return (
    <div className="fixed inset-0 bg-black text-white overflow-hidden">
      {/* Viewfinder */}
      <video ref={video} className="absolute inset-0 w-full h-full object-cover" muted playsInline autoPlay />
      <AnimatePresence>{flash && <motion.div className="absolute inset-0 bg-white" initial={{ opacity: 0.9 }} animate={{ opacity: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} />}</AnimatePresence>

      {/* Live boxes */}
      <AnimatePresence>
        {!draft && live.map((m) => (
          <motion.button
            key={m.name + Math.round(m.bounds[0] * 10) + Math.round(m.bounds[1] * 10)}
            type="button" aria-label={`Select ${m.name}`} onClick={() => shutter(m)}
            initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}
            className={`absolute rounded-2xl border-2 ${m.centered ? 'border-white' : 'border-white/60'}`}
            style={{ left: `${m.bounds[0] * 100}%`, top: `${m.bounds[1] * 100}%`, width: `${m.bounds[2] * 100}%`, height: `${m.bounds[3] * 100}%` }}
          >
            <span className="absolute -top-3 left-2 px-2 py-0.5 rounded-full bg-white text-ink text-[13px] font-semibold shadow">{m.name}</span>
          </motion.button>
        ))}
      </AnimatePresence>

      {/* Top bar */}
      <div className="absolute inset-x-0 top-0 flex items-center justify-between px-4 pt-[calc(var(--spacing-safe-t)+10px)] bg-gradient-to-b from-black/60 to-transparent pb-8">
        <button aria-label="Close camera" onClick={() => nav(`/rooms/${room.id}`)} className="w-11 h-11 rounded-full bg-white/15 backdrop-blur flex items-center justify-center active:scale-95"><X size={22} /></button>
        <div className="text-center">
          <div className="text-[15px] font-semibold">{room.name}</div>
          <div className="text-[13px] text-white/70">{count} tagged</div>
        </div>
        <div className="w-11 h-11 rounded-full bg-white/15 backdrop-blur flex items-center justify-center" aria-hidden><Zap size={18} className={state === 'live' && modelReady ? 'text-green-300' : 'text-white/50'} /></div>
      </div>

      {/* Bottom controls */}
      <div className="absolute inset-x-0 bottom-0 pb-[calc(var(--spacing-safe-b)+22px)] pt-10 bg-gradient-to-t from-black/70 to-transparent">
        <p className="text-center text-[15px] font-medium text-white/90 mb-5" role="status">{hint}</p>
        <div className="grid grid-cols-3 items-center px-8">
          <button aria-label="Add a photo from your library" onClick={() => fileRef.current?.click()} className="w-12 h-12 rounded-full bg-white/15 backdrop-blur flex items-center justify-center justify-self-start active:scale-95"><ImagePlus size={22} /></button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={fromFile} />
          <button aria-label="Capture item" disabled={state !== 'live'} onClick={() => shutter()} className="justify-self-center w-[76px] h-[76px] rounded-full border-[5px] border-white flex items-center justify-center active:scale-95 disabled:opacity-40">
            <span className="w-[60px] h-[60px] rounded-full bg-white" />
          </button>
          <button onClick={() => nav(`/rooms/${room.id}`)} className="justify-self-end min-h-12 px-4 rounded-full bg-white/15 backdrop-blur text-[15px] font-semibold active:scale-95">Done</button>
        </div>
      </div>

      <Toast show={!!saved} text={`Saved ${saved?.name ?? ''}`} onUndo={() => { if (saved) { store.deleteItem(saved.id); setSaved(null) } }} />

      {/* Tagging sheet */}
      <Sheet open={!!draft} onOpenChange={(o) => { if (!o) setDraft(null) }}>
        {draft && (
          <div className="text-ink">
            <div className="flex gap-4 items-start mb-4">
              <img src={draft.photo} alt="" className="w-24 h-24 rounded-2xl object-cover bg-surface-2 shrink-0" />
              <div className="flex-1 min-w-0">
                <label className="eyebrow block mb-1" htmlFor="item-name">Item</label>
                <input id="item-name" className="input" list="catalog" placeholder="What is it?" value={draft.name} autoFocus={!draft.name}
                  onChange={(e) => {
                    const name = e.target.value
                    const cat = itemCatalog.find((i) => i.name.toLowerCase() === name.trim().toLowerCase())
                    const s = ai.suggestTag(name)
                    setDraft({ ...draft, name, size: cat?.size ?? draft.size, tag: draft.tag ?? (s && s.tag !== 'undecided' ? s.tag : null) })
                  }} />
                <datalist id="catalog">{itemCatalog.map((i) => <option key={i.name} value={i.name} />)}</datalist>
              </div>
            </div>

            <div className="mb-4">
              <Segmented options={SIZE_OPTS} value={draft.size} onChange={(size) => setDraft({ ...draft, size })} />
            </div>

            <div className="mb-2 flex items-baseline justify-between">
              <span className="eyebrow">What should happen to it?</span>
              {(() => { const s = ai.suggestTag(draft.name); return s && s.tag !== 'undecided' && draft.tag !== s.tag ? <button className="text-[13px] font-semibold text-accent" onClick={() => setDraft({ ...draft, tag: s.tag })}>Suggest: {s.tag}</button> : null })()}
            </div>
            <TagChips value={draft.tag} onChange={(tag) => setDraft({ ...draft, tag })} />

            {draft.tag === 'family' && (
              <input className="input mt-3" placeholder="Who is it for? e.g. Sarah" value={draft.recipient} onChange={(e) => setDraft({ ...draft, recipient: e.target.value })} />
            )}

            <div className="grid grid-cols-[auto_1fr] gap-3 mt-5">
              <button className="btn btn-secondary w-auto px-5" onClick={() => setDraft(null)}>Retake</button>
              <button className="btn" disabled={!draft.name.trim() || !draft.tag} onClick={save}><Check size={20} /> Save and keep going</button>
            </div>
          </div>
        )}
      </Sheet>
    </div>
  )
}
