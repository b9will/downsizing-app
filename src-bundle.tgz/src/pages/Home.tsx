import { Link } from 'react-router-dom'
import { ArrowRight, Camera } from 'lucide-react'
import { Page, TagPill } from '../components/ui'
import { ai } from '../lib/ai'
import { useStore } from '../lib/hooks'
import { store } from '../lib/store'
import { TAGS, type Tag } from '../lib/types'

export default function Home() {
  const user = useStore(() => store.getUser())
  const job = useStore(() => store.getJob())
  const rooms = useStore(() => (job ? store.listRooms(job.id) : []))
  const items = useStore(() => (job ? store.listItems(job.id) : []))
  if (!job) return null

  const step = ai.nextStep(job, rooms, items)
  const next = rooms.find((r) => r.id === step.roomId)
  const done = rooms.filter((r) => r.done).length
  const pct = rooms.length ? Math.round((done / rooms.length) * 100) : 0
  const counts = (Object.keys(TAGS) as Tag[]).map((t) => ({ t, n: items.filter((i) => i.tag === t).length })).filter((c) => c.n > 0)

  return (
    <Page>
      <div className="flex items-center justify-between mb-6">
        <div className="eyebrow">{user?.name.split(' ')[0]}</div>
        <button className="text-[14px] font-semibold text-ink-2" onClick={() => { store.setUser(null); location.assign('/login') }}>Sign out</button>
      </div>

      <h1 className="text-[30px] font-bold leading-tight mb-2">{step.headline}</h1>
      <p className="text-ink-2 text-[18px] mb-6">{step.body}</p>

      {next && (
        <Link to={`/rooms/${next.id}/scan`} className="btn mb-8"><Camera size={22} /> Scan the {next.name.toLowerCase()}</Link>
      )}

      <div className="card mb-4">
        <div className="flex items-baseline justify-between mb-2">
          <span className="font-semibold">Progress</span>
          <span className="text-ink-2 text-[15px]">{done} of {rooms.length} rooms</span>
        </div>
        <div className="h-2.5 rounded-full bg-surface-2 overflow-hidden"><div className="h-full bg-accent rounded-full transition-[width] duration-300" style={{ width: `${pct}%` }} /></div>
        <div className="flex flex-wrap gap-2 mt-4">
          {counts.length ? counts.map((c) => <span key={c.t} className="inline-flex items-center gap-1.5 text-[14px] font-semibold"><TagPill tag={c.t} small /> {c.n}</span>) : <span className="text-ink-3 text-[15px]">Nothing tagged yet</span>}
        </div>
      </div>

      <Link to="/rooms" className="card flex items-center justify-between">
        <div><div className="font-semibold">All rooms</div><div className="text-ink-2 text-[15px]">{items.length} items tagged</div></div>
        <ArrowRight className="text-ink-3" />
      </Link>
    </Page>
  )
}
