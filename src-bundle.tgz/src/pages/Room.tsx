import { Link, useNavigate, useParams } from 'react-router-dom'
import { Camera, ChevronLeft } from 'lucide-react'
import { Page, TagPill } from '../components/ui'
import { useStore } from '../lib/hooks'
import { store } from '../lib/store'

export default function Room() {
  const { roomId = '' } = useParams()
  const nav = useNavigate()
  const job = useStore(() => store.getJob())
  const room = useStore(() => (job ? store.listRooms(job.id).find((r) => r.id === roomId) : undefined))
  const items = useStore(() => (job ? store.listItems(job.id, roomId) : []))
  if (!job || !room) return <Page><Link to="/rooms">Back to rooms</Link></Page>

  const toggleDone = () => {
    store.saveRoom({ ...room, done: !room.done })
    if (!room.done) {
      const next = store.listRooms(job.id).find((r) => !r.done && r.id !== room.id)
      nav(next ? `/rooms/${next.id}/scan` : '/summary')
    }
  }

  return (
    <Page>
      <Link to="/rooms" className="inline-flex items-center gap-1 text-ink-2 font-semibold text-[15px] mb-3"><ChevronLeft size={18} /> Rooms</Link>
      <div className="flex items-end justify-between mb-5">
        <div><h1 className="text-[30px] font-bold leading-tight">{room.name}</h1><p className="text-ink-2">{items.length ? `${items.length} item${items.length === 1 ? '' : 's'}` : 'Nothing yet'}</p></div>
        <Link to={`/rooms/${room.id}/scan`} className="btn w-auto px-5"><Camera size={20} /> Scan</Link>
      </div>

      {items.length === 0 ? (
        <Link to={`/rooms/${room.id}/scan`} className="card flex flex-col items-center text-center py-10 text-ink-2">
          <Camera size={36} className="mb-3 text-ink-3" />
          Point your camera at the first item
        </Link>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {items.map((i) => (
            <Link key={i.id} to={`/items/${i.id}`} className="card p-0 overflow-hidden">
              <div className="aspect-square bg-surface-2">{i.photo && <img src={i.photo} alt="" className="w-full h-full object-cover" />}</div>
              <div className="p-3">
                <div className="font-semibold truncate">{i.name}</div>
                <div className="mt-1"><TagPill tag={i.tag} small /></div>
              </div>
            </Link>
          ))}
        </div>
      )}

      <div className="flex flex-col gap-2 mt-8">
        <button className={`btn ${room.done ? 'btn-secondary' : ''}`} onClick={toggleDone}>{room.done ? 'Reopen this room' : 'This room is done'}</button>
        <Link to={`/rooms/${room.id}/new`} className="btn btn-ghost">Add an item without a photo</Link>
      </div>
    </Page>
  )
}
