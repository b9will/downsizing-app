import { Link } from 'react-router-dom'
import { Page, TagPill } from '../components/ui'
import { ai } from '../lib/ai'
import { useStore } from '../lib/hooks'
import { store } from '../lib/store'
import { TAGS, type Job, type Tag } from '../lib/types'

const money = (n: number) => n.toLocaleString('en-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 })
const TIERS: Array<[Job['tier'], string, string]> = [
  ['clear', 'Clear', 'Empty the home. Store, donate, sell or dispose of everything tagged.'],
  ['clear-move', 'Clear and Move', 'Plus pack and move your Move items to the new home.'],
  ['clear-move-settle', 'Clear, Move and Settle', 'Plus unpack, place furniture and remove every box.'],
]

export default function Summary() {
  const job = useStore(() => store.getJob())
  const rooms = useStore(() => (job ? store.listRooms(job.id) : []))
  const items = useStore(() => (job ? store.listItems(job.id) : []))
  const [sent, setSent] = [job?.status !== 'tagging', (v: boolean) => job && store.saveJob({ ...job, status: v ? 'review' : 'tagging' })]
  if (!job) return null

  const q = ai.estimateQuote(job, items)
  const undecided = items.filter((i) => i.tag === 'undecided')
  const unfinished = rooms.filter((r) => !r.done)
  const counts = (Object.keys(TAGS) as Tag[]).map((t) => ({ t, n: items.filter((i) => i.tag === t).length })).filter((c) => c.n > 0)

  return (
    <Page>
      <h1 className="text-[30px] font-bold mb-1">Summary</h1>
      <p className="text-ink-2 mb-5">A first estimate from what you've tagged. We confirm it before anything is booked.</p>

      <div className="card mb-3">
        <div className="eyebrow mb-2">Estimate</div>
        <div className="text-[32px] font-bold leading-none tabular-nums">{money(q.priceLow)} <span className="text-ink-3 font-medium">to</span> {money(q.priceHigh)}</div>
        <p className="text-ink-2 text-[14px] mt-2 mb-4">All-in before tax. Sale proceeds credited back.</p>
        <div className="grid grid-cols-4 gap-2 text-center">
          {[[q.crew, 'Crew'], [`${q.hours}h`, 'On site'], [q.boxes, 'Boxes'], [q.truck.replace(' truck', ''), 'Truck']].map(([n, l]) => (
            <div key={String(l)} className="bg-surface-2 rounded-xl py-3"><div className="font-bold text-[18px] tabular-nums">{n}</div><div className="text-[12px] text-ink-2">{l}</div></div>
          ))}
        </div>
        {(q.storageUnit || q.donationLoads || q.junkLoads || q.notes.length) ? (
          <ul className="text-[14px] text-ink-2 mt-4 pl-5 list-disc space-y-1">
            {q.storageUnit && <li>Storage: {q.storageUnit}, inventoried and photographed.</li>}
            {q.donationLoads > 0 && <li>{q.donationLoads} donation pickup{q.donationLoads === 1 ? '' : 's'} with tax receipts.</li>}
            {q.junkLoads > 0 && <li>{q.junkLoads} disposal load{q.junkLoads === 1 ? '' : 's'}.</li>}
            {q.notes.map((n) => <li key={n}>{n}</li>)}
          </ul>
        ) : null}
      </div>

      <div className="card mb-3">
        <div className="eyebrow mb-3">Service</div>
        <div className="flex flex-col gap-2">
          {TIERS.map(([v, label, desc]) => (
            <button key={v} type="button" aria-pressed={job.tier === v} onClick={() => store.saveJob({ ...job, tier: v })}
              className={`text-left rounded-2xl border-2 p-4 ${job.tier === v ? 'border-ink' : 'border-line'}`}>
              <div className="font-semibold">{label}</div><div className="text-ink-2 text-[14px]">{desc}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="card mb-3">
        <div className="eyebrow mb-3">Your items</div>
        <div className="flex flex-wrap gap-2">
          {counts.length ? counts.map((c) => <span key={c.t} className="inline-flex items-center gap-1.5 font-semibold text-[15px]"><TagPill tag={c.t} small /> {c.n}</span>) : <span className="text-ink-3">Nothing tagged yet.</span>}
        </div>
        {unfinished.length > 0 && <p className="text-ink-2 text-[14px] mt-3">Not marked done: {unfinished.map((r) => r.name).join(', ')}.</p>}
      </div>

      {undecided.length > 0 && (
        <div className="card mb-3">
          <div className="eyebrow mb-1">Still deciding ({undecided.length})</div>
          <p className="text-ink-2 text-[14px] mb-3">Tap to choose, or leave them and we'll call to help.</p>
          <div className="flex flex-col gap-2">
            {undecided.map((i) => (
              <Link key={i.id} to={`/items/${i.id}`} className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-surface-2 overflow-hidden shrink-0">{i.photo && <img src={i.photo} alt="" className="w-full h-full object-cover" />}</div>
                <div className="font-semibold">{i.name}</div>
              </Link>
            ))}
          </div>
        </div>
      )}

      <button className="btn" disabled={items.length === 0 || sent} onClick={() => setSent(true)}>{sent ? 'Sent. We are reviewing it.' : 'Send to our team'}</button>
      <p className="text-ink-3 text-[14px] text-center mt-3">You can keep tagging after sending.</p>
    </Page>
  )
}
