import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Page } from '../components/ui'
import { ensureJob, store, uid } from '../lib/store'

// Local-only sign in. Any email and any 6-digit code work in dev.
export default function Login() {
  const nav = useNavigate()
  const [step, setStep] = useState<'email' | 'code'>('email')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [code, setCode] = useState('')
  const [error, setError] = useState('')

  const sendCode = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return setError('Please enter your name.')
    if (!/.+@.+\..+/.test(email)) return setError('That email does not look right.')
    setError(''); setStep('code')
  }
  const verify = (e: React.FormEvent) => {
    e.preventDefault()
    if (!/^\d{6}$/.test(code)) return setError('Enter the 6 numbers from your email.')
    const user = { id: uid(), email: email.trim().toLowerCase(), name: name.trim(), role: 'client' as const }
    store.setUser(user); ensureJob(user); nav('/setup', { replace: true })
  }

  return (
    <Page className="min-h-full flex flex-col justify-center">
      <img src="/icon.svg" alt="" width={64} height={64} className="rounded-2xl mb-6" />
      <h1 className="text-[34px] font-bold leading-tight mb-2">Downsizing Companion</h1>
      <p className="text-ink-2 text-[18px] mb-8">Walk through your home. Point, tap, done. We take care of the rest.</p>

      {step === 'email' ? (
        <form onSubmit={sendCode} className="flex flex-col gap-3">
          <input id="name" className="input" placeholder="Your name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
          <input id="email" className="input" type="email" inputMode="email" autoComplete="email" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
          {error && <p role="alert" className="text-danger font-semibold">{error}</p>}
          <button className="btn mt-2" type="submit">Continue</button>
          <p className="text-ink-3 text-[15px] text-center">We'll email a 6-digit code. No password.</p>
        </form>
      ) : (
        <form onSubmit={verify} className="flex flex-col gap-3">
          <label htmlFor="code" className="eyebrow">Code sent to {email}</label>
          <input id="code" className="input text-center text-[30px] tracking-[0.4em]" inputMode="numeric" autoComplete="one-time-code" maxLength={6} autoFocus value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} />
          {error && <p role="alert" className="text-danger font-semibold">{error}</p>}
          <button className="btn mt-2" type="submit">Sign in</button>
          <button className="btn btn-ghost" type="button" onClick={() => setStep('email')}>Use a different email</button>
          <p className="text-ink-3 text-[15px] text-center">In development, any 6 numbers work.</p>
        </form>
      )}
    </Page>
  )
}
