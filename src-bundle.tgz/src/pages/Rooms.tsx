import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Camera, Check, Plus } from 'lucide-react'
import { Page } from '../components/ui'
import { useStore } from '../lib/hooks'
import { store, uid } from '../lib/store'

export default function Rooms() {
  const job = useStore(() => store.getJob())
  const rooms = useStore(() => (job ? store.listRooms(job.id) : []))
  const items = useStore(() => (job ? store.listItems(job.id) : []))
  const [name, setName] = useState('')
  const [adding, setAdding] = useState(false)
  if (!job) return null

  const add = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return
    store.saveRoom({ id: uid(), jobId: job.id, name: name.trim(), order: rooms.length, done: false })
    setName(''); setAdding(false)
  }

  return (
    <Page>
      <h1 className="text-[30px] font-bold mb-1">Rooms</h1>
      <p className="text-ink-2 mb-5">Tap a room to scan it.</p>
      <div className="flex flex-col gap-2">
        {rooms.map((r) => {
          const n = items.filter((i) => i.roomId === r.id).length
          const last = items.find((i) => i.roomId === r.id && i.photo)
          return (
            <div key={r.id} className="card flex items-center gap-4 p-3">
              <Link to={`/rooms/${r.id}`} className="flex items-center gap-4 flex-1 min-w-0">
                <div className="w-14 h-14 rounded-xl bg-surface-2 overflow-hidden flex items-center justify-center shrink-0">
                  {last?.photo ? <img src={last.photo} alt="" className="w-full h-full object-cover" /> : r.done ? <Check className="text-accent" /> : <span className="text-ink-3 font-semibold">{n || ''}</span>}
                </div>
                <div className="min-w-0">
                  <div className="font-semibold truncate">{r.name}</div>
                  <div className="text-ink-2 text-[14px]">{r.done ? 'Done' : n ? `${n} item${n === 1 ? '' : 's'}` : 'Not started'}</div>
                </div>
              </Link>
              <Link to={`/rooms/${r.id}/scan`} aria-label={`Scan ${r.name}`} className="w-12 h-12 rounded-full bg-accent text-white flex items-center justify-center active:scale-95 shrink-0"><Camera size={22} /></Link>
            </div>
          )
        })}
      </div>

      {adding ? (
        <form onSubmit={add} className="flex gap-2 mt-4">
          <input className="input" autoFocus placeholder="Room name" value={name} onChange={(e) => setName(e.target.value)} />
          <button className="btn w-auto px-5" type="submit">Add</button>
        </form>
      ) : (
        <button className="btn btn-secondary mt-4" onClick={() => setAdding(true)}><Plus size={20} /> Add a room</button>
      )}
    </Page>
  )
}
