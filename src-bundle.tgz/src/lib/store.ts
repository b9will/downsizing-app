// Data layer. Local-first (localStorage) today; swap `LocalStore` for a
// Supabase-backed implementation of the same `Store` interface later.
import type { Item, Job, Room, User } from './types'

const KEY = 'downsizing.v1'

interface DB {
  user: User | null
  jobs: Job[]
  rooms: Room[]
  items: Item[]
}

export interface Store {
  getUser(): User | null
  setUser(u: User | null): void
  getJob(): Job | null
  saveJob(j: Job): void
  listRooms(jobId: string): Room[]
  saveRoom(r: Room): void
  deleteRoom(id: string): void
  listItems(jobId: string, roomId?: string): Item[]
  getItem(id: string): Item | null
  saveItem(i: Item, requirePersistence?: boolean): void
  deleteItem(id: string): void
  subscribe(fn: () => void): () => void
}

const empty: DB = { user: null, jobs: [], rooms: [], items: [] }

function load(): DB {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? { ...empty, ...JSON.parse(raw) } : { ...empty }
  } catch {
    return { ...empty }
  }
}

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
export const now = () => new Date().toISOString()

class LocalStore implements Store {
  private db: DB = load()
  private subs = new Set<() => void>()

  private commit(requirePersistence = false) {
    try { localStorage.setItem(KEY, JSON.stringify(this.db)) } catch (error) { if (requirePersistence) throw error }
    this.subs.forEach((fn) => fn())
  }

  subscribe(fn: () => void) { this.subs.add(fn); return () => { this.subs.delete(fn) } }

  getUser() { return this.db.user }
  setUser(u: User | null) { this.db.user = u; this.commit() }

  getJob() { return this.db.jobs[0] ?? null }
  saveJob(j: Job) {
    const i = this.db.jobs.findIndex((x) => x.id === j.id)
    if (i >= 0) this.db.jobs[i] = j; else this.db.jobs.push(j)
    this.commit()
  }

  listRooms(jobId: string) { return this.db.rooms.filter((r) => r.jobId === jobId).sort((a, b) => a.order - b.order) }
  saveRoom(r: Room) {
    const i = this.db.rooms.findIndex((x) => x.id === r.id)
    if (i >= 0) this.db.rooms[i] = r; else this.db.rooms.push(r)
    this.commit()
  }
  deleteRoom(id: string) {
    this.db.rooms = this.db.rooms.filter((r) => r.id !== id)
    this.db.items = this.db.items.filter((i) => i.roomId !== id)
    this.commit()
  }

  listItems(jobId: string, roomId?: string) {
    return this.db.items
      .filter((i) => i.jobId === jobId && (!roomId || i.roomId === roomId))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  }
  getItem(id: string) { return this.db.items.find((i) => i.id === id) ?? null }
  saveItem(i: Item, requirePersistence = false) {
    const previous = this.db.items
    this.db.items = [...previous]
    const idx = this.db.items.findIndex((x) => x.id === i.id)
    if (idx >= 0) this.db.items[idx] = i; else this.db.items.push(i)
    try {
      this.commit(requirePersistence)
    } catch (error) {
      this.db.items = previous
      throw error
    }
  }
  deleteItem(id: string) { this.db.items = this.db.items.filter((i) => i.id !== id); this.commit() }
}

export const store: Store = new LocalStore()

// Seed a first job and the usual rooms for a new user.
export function ensureJob(user: User): Job {
  let job = store.getJob()
  if (job) return job
  const deadline = new Date(); deadline.setDate(deadline.getDate() + 14)
  job = {
    id: uid(),
    clientName: user.name,
    address: '',
    tier: 'clear-move',
    moveDate: null,
    tagDeadline: deadline.toISOString(),
    status: 'tagging',
    createdAt: now(),
  }
  store.saveJob(job)
  const defaults = ['Living room', 'Kitchen', 'Dining room', 'Primary bedroom', 'Second bedroom', 'Bathroom', 'Basement', 'Garage']
  defaults.forEach((name, order) => store.saveRoom({ id: uid(), jobId: job!.id, name, order, done: false }))
  return job
}
