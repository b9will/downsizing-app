import type { SizeClass } from './types'
import type { ObjectDetection } from '@tensorflow-models/coco-ssd'

let model: Promise<ObjectDetection> | undefined

const typicalSizes: Record<string, SizeClass> = {
  bed: 'large', refrigerator: 'large', oven: 'large', 'dining table': 'large',
  chair: 'medium', bicycle: 'large', microwave: 'medium', suitcase: 'medium',
  laptop: 'small', keyboard: 'small', bottle: 'small', book: 'small',
  bowl: 'small', cup: 'small', 'cell phone': 'small', vase: 'small',
}

export async function identifyItems(photo: string | HTMLVideoElement) {
  model ??= Promise.all([import('@tensorflow/tfjs'), import('@tensorflow-models/coco-ssd')])
    .then(async ([tf, coco]) => {
      await tf.ready()
      return coco.load({ base: 'lite_mobilenet_v2' })
    })
    .catch((error) => {
      model = undefined
      throw error
    })

  const image = typeof photo === 'string' ? new Image() : photo
  if (typeof photo === 'string' && image instanceof HTMLImageElement) {
    image.src = photo
    await image.decode()
  }
  const detector = await model
  const width = image instanceof HTMLVideoElement ? image.videoWidth : image.naturalWidth
  const height = image instanceof HTMLVideoElement ? image.videoHeight : image.naturalHeight
  if (!width || !height) return []
  const detections = await detector.detect(image, 20, 0.55)
  const centerX = width / 2
  const centerY = height / 2
  return detections
    .filter(({ class: label }) => label !== 'person')
    .sort((a, b) => Number(coversCenter(b.bbox)) - Number(coversCenter(a.bbox)) || b.score - a.score)
    .slice(0, 5)
    .map(({ class: label, bbox }) => ({
      name: label === 'couch' ? 'Sofa' : label === 'tv' ? 'TV' : label[0].toUpperCase() + label.slice(1),
      size: typicalSizes[label],
      bounds: bbox.map((value, index) => value / (index % 2 === 0 ? width : height)),
      centered: coversCenter(bbox),
    }))

  function coversCenter([x, y, width, height]: number[]) {
    return centerX >= x && centerX <= x + width && centerY >= y && centerY <= y + height
  }
}
