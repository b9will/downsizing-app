export type Tag =
  | 'keep'
  | 'move'
  | 'family'
  | 'sell'
  | 'store'
  | 'donate'
  | 'junk'
  | 'undecided'

export type SizeClass = 'small' | 'medium' | 'large' | 'oversize'

export const TAGS: Record<Tag, { name: string; desc: string; color: string }> = {
  keep: { name: 'Keep', desc: 'Stays where it is', color: 'var(--tag-keep)' },
  move: { name: 'Move', desc: 'Goes to the new home', color: 'var(--tag-move)' },
  family: { name: 'Family', desc: 'Goes to a relative', color: 'var(--tag-family)' },
  sell: { name: 'Sell', desc: 'Has resale value', color: 'var(--tag-sell)' },
  store: { name: 'Store', desc: 'Keep, but not now', color: 'var(--tag-store)' },
  donate: { name: 'Donate', desc: 'Usable, give away', color: 'var(--tag-donate)' },
  junk: { name: 'Junk', desc: 'Dispose or recycle', color: 'var(--tag-junk)' },
  undecided: { name: 'Not sure', desc: 'We will help you decide', color: 'var(--tag-undecided)' },
}

export const SIZES: Record<SizeClass, string> = {
  small: 'Small (fits in a box)',
  medium: 'Medium (lamp, chair)',
  large: 'Large (dresser, sofa)',
  oversize: 'Oversize (piano, wardrobe)',
}

export interface User {
  id: string
  email: string
  name: string
  role: 'client' | 'family' | 'admin'
}

export interface Job {
  id: string
  clientName: string
  address: string
  tier: 'clear' | 'clear-move' | 'clear-move-settle'
  moveDate: string | null
  tagDeadline: string
  status: 'tagging' | 'review' | 'quoted' | 'scheduled' | 'done'
  createdAt: string
}

export interface Room {
  id: string
  jobId: string
  name: string
  order: number
  done: boolean
}

export interface Item {
  id: string
  jobId: string
  roomId: string
  name: string
  tag: Tag
  size: SizeClass
  photo?: string
  note?: string
  familyRecipient?: string
  createdAt: string
  updatedAt: string
}

export interface Quote {
  crew: number
  hours: number
  truck: string
  boxes: number
  storageUnit: string | null
  donationLoads: number
  junkLoads: number
  priceLow: number
  priceHigh: number
  notes: string[]
}
