import { BrowserRouter, Navigate, Outlet, Route, Routes } from 'react-router-dom'
import Shell from './components/Shell'
import { useStore } from './lib/hooks'
import { store } from './lib/store'
import { cameraGrantedBefore } from './lib/camera'
import CameraSetup from './pages/CameraSetup'
import Home from './pages/Home'
import ItemForm from './pages/ItemForm'
import Login from './pages/Login'
import Room from './pages/Room'
import Rooms from './pages/Rooms'
import Scan from './pages/Scan'
import Summary from './pages/Summary'

function RequireAuth() {
  const user = useStore(() => store.getUser())
  if (!user) return <Navigate to="/login" replace />
  return <Outlet />
}

function RequireCamera() {
  return cameraGrantedBefore() ? <Outlet /> : <Navigate to="/setup" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route element={<RequireAuth />}>
          <Route path="/setup" element={<CameraSetup />} />
          <Route element={<RequireCamera />}>
            <Route path="/rooms/:roomId/scan" element={<Scan />} />
            <Route element={<Shell />}>
              <Route path="/" element={<Home />} />
              <Route path="/rooms" element={<Rooms />} />
              <Route path="/rooms/:roomId" element={<Room />} />
              <Route path="/rooms/:roomId/new" element={<ItemForm />} />
              <Route path="/items/:itemId" element={<ItemForm />} />
              <Route path="/summary" element={<Summary />} />
            </Route>
          </Route>
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
